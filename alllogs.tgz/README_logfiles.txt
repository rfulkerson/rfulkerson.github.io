There are five log files here:

* twenty.log, which contains 20 Apache logfile entries, a perfect size to start testing your code with
* hundred.log, which contains 100 Apache logfile entries, a good next step for testing
* small.log, which contains 250 Apache logfile entries
* medium.log, which contains 500 Apache logfile entries
* monster.log, which contains 1000 Apache logfile entries

There are also five summary files to match the above log files::

* twenty.summary, which summarizes the results of twenty.log
* hundred.summary, which summarizes the results of hundred.log
* small.summary, which summarizes the results of small.log
* medium.summary, which summarizes the results of medium.log
* monster.summary, which summarizes the results of monster.log

Finally, there's a summary file that provides results for summarizing both small.log and medium.log during the same run:

* bothsmallmedium.summary, which summarizes the results of passing both small.log and medium.log as command-line arguments
